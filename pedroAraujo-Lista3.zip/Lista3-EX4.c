#include<stdio.h> 
#include<stdlib.h> 
#include<math.h> 

int main(){ 
 
 int x; 
 int vet[9]; 
 int num; 
 int achei=0; 
 
 
 
    for(x=0;x<9;x++){ 
     
	 printf("\n[%d] Digite um numero: ",x); 
    scanf("%d",&vet[x]);
	 
 } 
 
 printf("\n\n");
  
 printf("Digite um valor a ser pesquisado: "); 
 scanf("%d",&num); 
 
    for(x=0;x<9;x++) 
 
      if(vet[x]==num){ 
       printf("\n O numero %d esta na posicao %d: ",num,x); 
       achei=1; 
       
 } 
 
      if(achei!=1) 
       printf("\n Este numero nao existe"); 
 
 printf("\n\n"); 
 
 return(0); 
 
} 
