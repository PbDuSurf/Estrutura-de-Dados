#include<stdio.h> 
#include<stdlib.h> 
#include<string.h> 

int main() {
 
 int numero;
 int maior=numero; 
 
 printf("\nDigite um numero inteiro: "); 
 scanf("%d",&numero); 
 
 while(numero!=0) {
  
    if(numero>maior) 
    maior=numero; 
 
 printf("\nDigite outro numero(PARA ENCERRAR DIGITE 0) : "); 
 scanf("%d",&numero); 
 }
  
 printf("\nMaior numero ->: %d",maior); 
 
 printf("\n\n"); 
  
 return(0); 
 } 
