#include<stdio.h> 
#include<stdlib.h> 
#include<string.h> 
#include<math.h> 
int main() {
 
 system("color F5"); 
 
 int z; 
 float vetcubo[10], vet[10]; 
 
 
    for(z=0;z<10;z++){ 
      printf("Digite um numero: "); 
      scanf("%f",&vet[z]); 
      
	  printf("\n"); 
    
	vetcubo[z]=pow(vet[z],3); 
 }
  
    for(z=0;z<10;z++) 
      printf("%3.2f\t", vetcubo[z]); 
      
 printf("\n"); 
 
 return(0); 
}
