#include<stdio.h> 
#include<stdlib.h> 
#include<math.h> 
#include<conio.h> 
#include<string.h> 
 
 int main(){ 
  
 int z, vet[21], t=20; 
  
  for(z=0; z<21; z++){ 
  vet[z]= t; 
  t++; 

 } 
 printf("\n\n"); 
 
 for(z=21; z>=1; z=z-2) 
 
 printf("%d\t",vet[z]); 
 printf("\n"); 
 
 system("pause"); 
 return(0); 
} 
