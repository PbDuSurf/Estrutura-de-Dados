#include<stdio.h> 
#include<stdlib.h> 
#include<math.h> 

int main(){ 
 
 int vet[20],x, y=0; 
  
    for(x=0;x<=19;x++) { 
 
    vet[x]=y+2; 
 
    y=y+2; 
} 
 
    for(x=0;x<=19;x++) 
	 
     printf(" %d ",vet[x]); 
     
 printf("\n\n"); 
 
 return(0); 
 
} 

