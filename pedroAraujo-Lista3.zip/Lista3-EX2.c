#include<stdio.h> 
#include<stdlib.h> 
int main() {
 
 int num; 
 
 printf("\n\n Digite um numero entre 1 e 99: "); 
 scanf("%d",&num); 
 
 
 while(num<1||num>99){
  
 printf("\n O numero esta incorreto, digite novamente : "); 
 scanf("%d",&num);
  
 }
  
 printf("\n\n O numero digitado e:% d",num); 
 
 printf("\n\n"); 
 
 return(0); 
 } 
