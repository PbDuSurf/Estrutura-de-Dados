#include<stdio.h> 
#include<stdlib.h> 
#include<string.h> 
int main(){ 
 
 int idade;
 int contador18=0;
 int contador60=0; 
 
 printf("\n Digite a idade: "); 
 scanf("%d",&idade); 
 
 while(idade!=-1){
  
    if(idade<18) 
      contador18++; 
 
    if(idade>60) 
      contador60++; 
  
  printf("\nDigite a idade(Para finalizar o programa digite:-1) : "); 
  scanf("%d",&idade); 
 }
  
 printf("\n Total de pessoas com menos de 18 e:%d",contador18); 
 
 printf("\n Total de pessoas com mais de 60 e:%d",contador60); 
 
 printf("\n\n"); 
 
  
 return(0); 
} 
