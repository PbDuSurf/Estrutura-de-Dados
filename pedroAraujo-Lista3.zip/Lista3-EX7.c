#include<stdio.h> 
#include<stdlib.h> 
#include <string.h> 
#include<math.h> 
int main(){ 
 
 int ENT1[3], ENT2[3], media[3]; 
 char nome[3][30];
 char nome1[3][30]; 
 char situacao[3][50]; 
 int x; 
 int y=1; 
 
    
	for(x=0;x<3;x++) { 
     printf("Informe nome %d: ",x+1); 
     gets(nome[x]); 
 
   printf("Informe nota %d do aluno %s: ",y,nome[x]); 
   scanf("%f",&ENT1[x]); 
   gets(nome1[x]); 
   y++; 
 
   printf("Informe nota %d do aluno %s: ",y,nome[x]); 
   scanf("%f",&ENT2[x]); 
   gets(nome1[x]); 
   y=1; 
 } 
 
 for(x=0;x<=60;x++){
  
 media[x]=(ENT1[x]+ENT2[x])/2; 
 
    if(media[x]>60) 
    strcpy(situacao[x],"Aprovado"); 
 
    else 
    strcpy(situacao[x],"Reprovado"); 
 } 
 
 printf("__________________________________________________________________"); 
  printf("\n\nNome\tNota1\t\tNota2\tMedia\tSituacao"); 
   printf("\n________________________________________________________________"); 
 
    for(x=0;x<3;x++){
	 
 printf("\n%s\t%3.2f\t\t%3.2f\t%3.2f\t%s",nome[x],ENT1[x],ENT2[x],media[x],situacao[x]); 
  
  } 
    
	printf("\n________________________________________________________________"); 
 
    printf("\n\n"); 
  
 return(0);
  
 }
