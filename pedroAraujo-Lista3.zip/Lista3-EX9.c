#include<stdio.h> 
#include<stdlib.h> 
#include<math.h> 
#include<conio.h> 
#include<string.h> 

int main(){  
 int z, vet[21], t=20; 
    
	for(z=0; z<21; z++){
	 
   vet[z]= t; 
   t++; 
 //printf("%d\t",vet[z]); Caso eu quisesse mostrar o vetor completo 
 } 
 printf("\n\n"); 
 
   for(z=0; z<21; z=z+2) 
 
   printf("%d\t",vet[z]); 
   printf("\n"); 
 
 system("pause"); 
 return(0); 
} 
