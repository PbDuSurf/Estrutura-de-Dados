
#include <stdio.h>
 
int calculoPotencia(int num1, int num2);
int calculoPotenciaCauda(int num1, int num2, int result);

int main(){
    int x, n;
    
    printf("Digite um numero X:");
    scanf("%d", &x);
    printf("Digite um numero N:");
    scanf("%d", &n);

    printf("Resultado: %d\n", calculoPotencia(x,n));
    printf("Resultado: %d\n", calculoPotenciaCauda(x,n,x));
    return 0;
}

int calculoPotencia(int num1, int num2){
    if(num2>1){
        return num1*calculoPotencia(num1, num2-1); //2 elevado a 3:   2 3 2*? - 2 2 2*? - 2 1 2
    }else{ //se num2 for igaul a 1                                    // r=8       r=4       r=2  
       return num1; 
    }
}

int calculoPotenciaCauda(int num1, int num2, int result){
    if(num2>1){
        return calculoPotenciaCauda(num1, num2-1, result*num1);  //2 elevado a 5: 2 5 2 - 2 4 4 - 2 3 8 - 2 2 16 - 2 1 32 
    }else{ 
       return result; 
    }
}
