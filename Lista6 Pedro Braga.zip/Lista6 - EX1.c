#include <stdio.h>

void recursiviadeChar();
char nome[30];
char *ponteiro;

int main() {
	int length;
	
	ponteiro = &nome[0];
	
	printf("\nDigite um nome:");
	fgets(nome, 30, stdin);
	
	length = 0;
	
	recursiviadeChar(length);
	
	return 0;
}
void recursiviadeChar(int length) {

if(length < 3) {
printf("%c", *(ponteiro+length));
length++;

recursiviadeChar(length);
	}
}
