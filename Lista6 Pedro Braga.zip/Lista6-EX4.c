
#include <stdio.h>

int vet[6] = {10, 11, 12, 13, 14, 15};

int somaVet(int num);
int somaVetCauda();

int main(){
    int tam = 6;

    printf("Resultado: %d\n", somaVet(tam-1));
    printf("Resultado: %d\n", somaVetCauda(tam-1, 0));
    return 0;
}

int somaVet(int num){ 
    if(num<0){
        return 0;
    }else{
        return vet[num]+somaVet(num-1);
    }
}

int somaVetCauda(int num, int result){
    if(num<0){
        return result;
    }else{
        return somaVetCauda(num-1, result+vet[num]);
    }
}
