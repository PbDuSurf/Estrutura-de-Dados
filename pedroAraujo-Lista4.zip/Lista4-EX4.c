#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void maiorMenor(int *vet,int tam,int *menor,int *maior){

*menor=*vet;
*maior=*vet;

for(int x=0;x<tam;x++){
if(*menor>*(vet+x)){
*menor=*(vet+x);
}
if(*maior<*(vet+x)){
*maior=*(vet+x);
}
}
}

int main(){
int num[4],menor,maior;

for(int x=0;x<4;x++){
printf("\n Informe um valor: ");
scanf("%d",&num[x]);
}

maiorMenor(num,4,&menor,&maior);

printf("\n O maior numero do vetor e: %d", maior);
printf("\n O menor numero do vetor e: %d", menor);

return 0;
}
