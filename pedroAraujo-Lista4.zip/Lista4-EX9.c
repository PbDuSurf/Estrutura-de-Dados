#include <stdio.h>
#include <stdlib.h>
#define N 100

int main (){
int mat[N][N];
int *p;
int i, j, soma = 0;

    p = &mat[0][0];   

   for (i=0; i<N; i++)
     for (j=0; j<N; j++){
    *p = 0;
    p++;
   }


    p = &mat[0][0];

  for (i=0; i<N; i++)
    for (j=0; j<N; j++){
    	
    *p = soma;
    soma++;
    p++;
  }
  return 0;  
}
