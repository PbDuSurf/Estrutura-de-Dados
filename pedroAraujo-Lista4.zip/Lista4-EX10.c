#include <stdio.h>
#include <stdlib.h>

int main(){
	char m[10][20],ma[10][20];
    char *p,c;
    int V[10]={0},aux[10]={0};
    int i,j,temp,y;

    for(i=0;i<10;i++){
        printf("\n Digite uma frase N.%d : ",i+1);
        gets(m[i]);                     
    }

    for(i=0;i<10;i++){
        p=m[i];                         
        c=*p;                     
        V[i]=c;                    
        aux[i]=V[i];                    
    }

    for( i=0; i<10; i++ ){              
        for( j=i+1; j<10; j++ ){
            if( V[i] > V[j] ){
                temp = V[i];
                V[i] = V[j];
                V[j] = temp;
            }
        }
    }

    for(i=0;i<10;i++){
        for(j=0;j<10;j++){
            if(aux[i]==V[j]){           
                for(y=0;y<10;y++) ma[j][y] = m[i][y];           
            }
        }
    }

    printf("\n A Matriz e:");
    for(i=0;i<10;i++){
        printf("\n  ");
        printf("%s ",ma[i]);          
    }
}
