#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(){
int a,b;
int *pa,*pb;

printf("\nDigite um numero: ");
scanf("%d", &a);
printf("\nDigite um numero: ");
scanf("%d", &b);
pa = &a;
pb = &b;

printf("\nA soma dos numeros e: %d", *pa + *pb);
printf("\nA subtra�ao dos numeros e: %d", *pa - *pb);
printf("\nO produto dos numeros e: %d", *pa * *pb);
printf("\nA divisao dos numeros e: %d", *pa / *pb);

return 0;
}

