#include <stdio.h>

int main(){

   int a,b,c;
   int *Pa = &a;
   int *Pb = &b;
   int *Pc = &c;

   printf("Digite o 1 valor:\n");
   scanf("%d",Pa);

   printf("Digite o 2 valor:\n");
   scanf("%d",Pb);

   printf("Digite o 3 valor:\n");
   scanf("%d",Pc);

   printf("\nOrdem crescente:\n");

   if(*Pa<*Pb && *Pa<*Pc){
       printf("\n%d --> %d",*Pa,Pa);

}
   else if(*Pb<*Pa && *Pb<*Pc){
       printf("\n%d --> %d",*Pb,Pb);

}
   else if(*Pc<*Pa && *Pc<*Pb){

       printf("\n%d --> %d",*Pc,Pc);

}
   if(*Pa>*Pb && *Pa<*Pc){

       printf("\n%d --> %d",*Pa,Pa);

}
   else if(*Pa>*Pc && *Pa<*Pb){

       printf("\n%d --> %d",*Pa,Pa);

}
   else if(*Pb>*Pa && *Pb<*Pc){

       printf("\n%d --> %d",*Pb,Pb);

}
   else if(*Pb>*Pc && *Pb<*Pa){

       printf("\n%d --> %d",*Pb,Pb);

}
   else if(*Pc>*Pa && *Pc<*Pb){

       printf("\n%d --> %d",*Pc, Pc);

}
   else if(*Pc>*Pb && *Pc>*Pa){

       printf("\n%d --> %d",*Pc, Pc);

}
   if(*Pa>*Pb && *Pa>*Pc) {
        printf("\n%d --> %d",*Pa,Pa);

}
   else if(*Pb>*Pa && *Pb>*Pc){

       printf("\n%d --> %d",*Pb,Pb);

}
 else if(*Pc>*Pa && *Pc>*Pb){

       printf("\n%d --> %d",*Pc,Pc);
}

  return 0;

}
