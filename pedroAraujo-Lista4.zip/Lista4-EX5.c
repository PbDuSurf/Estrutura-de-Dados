#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char opcao, frase[40];
	int  cont, qnt, tamanho ;
	char *pnt;
	
	do{
		pnt = &frase[0];
		qnt = 0;
		
		printf("Digite uma frase: ");
		gets (frase);
		tamanho = strlen(frase);
	
	while((frase[0]=='\0') || tamanho>100){
		puts("ERRO, Digite a frase novamente");
		gets(frase);
		tamanho = strlen(frase);					
	}
	for (cont=0; cont<40; cont++){
		if(*pnt=='\0')
		break;
	qnt++;
	pnt++;	
	}
	
	pnt = &frase[0];
	printf("\nA frase %c");
	
	for (cont=0; frase[cont]!='\0'; cont++){
		printf("%c", *pnt);
		pnt++;
   }
   
   printf("%c tem %d caracteres", qnt);
   printf("\n digite novamente S/N");
   
   scanf("%c",&opcao);
   fflush(stdin);
   
   while(opcao!='s'&& opcao!='S'&& opcao!='n'&& opcao!='N'){
   	
   }

return  0;
}
   
   


		
