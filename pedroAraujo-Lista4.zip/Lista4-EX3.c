#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char opcao;
	int vet[6],cont;
	int *pnt;
	
	do
	{
		pnt=&vet[0];
		printf("Digite seis numeros inteiros:\n ");
		
		for(cont=0;cont<6;cont++){
			printf("[%d]",cont+1);
			scanf("%d",pnt);
			pnt++;
}
	return 0;					
}


	
				

