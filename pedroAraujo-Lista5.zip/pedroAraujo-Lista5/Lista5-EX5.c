#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int *preencherVetor(int *vet, int n){
    for(int x = 0 ; x < n; x++){
        printf("Digite um numero: ");
        scanf("%d", vet+x);
        printf("\n");
    }
}

void mostrarVetor( int *vet, int n){
    for(int x = 0 ; x < n; x++){
        printf("{ %d }", *(vet+x)-1);
    }
}

int main(){
    int n;
    
    printf("Digite um tamanho para o vetor:\n");
    scanf("%d", &n);
    
    int vet = (int)malloc(sizeof(int)*n);
    
    preencherVetor(vet,n);
    mostrarVetor(vet,n);
    free(vet);
    
    return 0;
}
