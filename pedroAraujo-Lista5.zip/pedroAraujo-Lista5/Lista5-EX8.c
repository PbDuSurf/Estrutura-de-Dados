#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int *soma(int *vet1, int *vet2, int tam) {
 
 int i;
 int *vet3 = (int*)malloc(tam * sizeof(int));

   for (i=0; i<tam; i++) {
    vet3[i] = vet1[i] + vet2[i];
 }
 return vet3;
 }

 void main(){
 
 int tam, i, *pvet1, *pvet2, *pvet3;
 printf("Informe o tamanho desejado:\n");
 scanf("%d", &tam);
 
 pvet1 = (int*)malloc(tam * sizeof(int));
 pvet2 = (int*)malloc(tam * sizeof(int));

   for (i=0; i<tam; i++) {
    printf("Informe o numero %d do vetor 1:\n", i+1);
    scanf("%d", &pvet1[i]);
 
 }
 
   for (i=0; i<tam; i++) {
    printf("Informe o numero %d do vetor 2:\n", i+1);
     scanf("%d", &pvet2[i]);
     
 }

 pvet3 = soma(pvet1, pvet2, tam);

    for (i=0; i<tam; i++) {
     printf("Numero: %d\n", pvet3[i]);
 }

 free(pvet1);
 free(pvet2);
 free(pvet3);
}

