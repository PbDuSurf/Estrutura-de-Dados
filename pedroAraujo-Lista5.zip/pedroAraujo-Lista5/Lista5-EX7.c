#include <stdio.h>
#include <stdlib.h>


void reverse( char str[] )
{
    char * ptr = str;

    while( ptr && *ptr )
        ptr++;

    for( ptr--; str < ptr; str++, ptr-- )
    {
        *str = *str ^ *ptr;
        *ptr = *str ^ *ptr;
        *str = *str ^ *ptr;
    }
}


int main( void )
{
    char txt[40];
    printf("Digite uma frase:");
    gets(txt);
    
    reverse( txt );

    printf("%s\n", txt );

    return 0;
}

