#include <stdio.h>
#include  <stdlib.h>

int  estaContido ( int elemento, int **matriz, int numLin, int numCol) {
	
	int i, j;
	
	for (i= 0 ; i<numLin; i++) {
		for (j= 0 ; j<numCol; j++)
			if (matriz[i][j] == elemento)
				return  1 ;
	}
	
	return  0 ;
}

   void  sair () {
   	 
	printf ( " \n ERRO AO ALOCAR MEM�RIA! \n " );
	gets ( 1 );
}

   int  main () {
	
	int **matriz;
	int numLin, numCol;
	int i, j, opcao;
	
	printf ( " \n Informe o numero de linhas: " );
	scanf ( " %d " , &numLin);
	
	printf ( " Informe o numero de colunas: " );
	scanf ( " %d " , &numCol);
	
	matriz = ( int **) malloc (numLin * sizeof ( int *));
	
	if (matriz == NULL ) sair ();
	
	for (i= 0 ; i<numLin; i++) {
		matriz[i] = ( int *) malloc (numCol * sizeof ( int ));
		
		if (matriz[i][ 0 ] == NULL ) sair ();
		
		for (j= 0 ; j<numCol; j++) {
			printf ( " [ %d ][ %d ]: " ,(i+ 1 ),(j+ 1 ));
			scanf ( " %d " , &matriz[i][j]);
		}
	
	}
	
	do {
		printf ( " Digite o elemento que deseja procurar na matriz: " );
		scanf ( " %d " , &j);
		
		( estaContido (j, matriz, numLin, numCol))
			? printf ( " O elemento %d existe na matriz. \n " , j)
			: printf ( " O elemento %d nao existe na matriz. \n " , j);
		
		printf ( " \n Deseja procurar outro elemento? (n=0/s=1) " );
		scanf ( " %d " , &opcao);
		
		putchar ( ' \n ' );
			
	} while (opcao== 1 );
	
	printf ( " \n Programa finalizado! \n " );
	
}
