#include <stdio.h>
#include <stdlib.h>

  void main(){
   
   int i, N, *V;

 do {
    
	printf("Informe um valor N nao negativo:\n");
      scanf("%d", &N);
 
 if (N <= 0)
 printf("Valor invalido!\n");
 } 
 while (N <= 0);

 V = (int*) malloc(N * sizeof(int));
   
   for (i=0; i<N; i++) {
 
 do {
   
   printf("Informe o valor inteiro >= 2:\n");
    scanf("%d", &V[i]);
 
 if (V[i] < 2)
   printf("Valor invalido!\n");
   
 } 
 
 while (V[i] < 2);
 
 }

    for (i=0; i<N; i++) {
     printf("Valor: %d\n", V[i]);
 
 }
    free(V);
    
 }

