#include <stdio.h>
#include  <stdlib.h>

 int *alocaVet(int tam) {
 int i, *vet;

 if (tam > 0) {

 vet = (int*) malloc(tam * sizeof(int));
 return vet;
 
}
 else
 return NULL;
 
}

 void main(){
 
 int i, N, *V;

   printf("Informe um valor N:\n");
    scanf("%d", &N);

 V = alocaVet(N);

  if (V != NULL) {
   printf("Alocado corretamente!\n");
   free(V);

 }

  else
   printf("Erro na alocacao!\n");
 
}

