#include <stdio.h>
#include <stdlib.h>

  int *aloca_vetor(int *, int);
  void libera_vetor(int *);
  void imprime_vetot(int *, int);

int main(){

    int n; 
	int *vet = NULL;
	int i;

    printf("Informe o tamanho do vetor: ");
    scanf("%d", &n);

    vet = aloca_vetor(vet, n);

    printf("\nPreencha o vetor agora.\n");

    for(i = 0; i < n; i++){
        printf("Vetor [%d]: ",i);
        scanf("%d", &vet[i]);
    }

    imprime_vetor(vet, n);

    libera_vetor(vet);

    printf("\n\nO vetor depois de liberar.\n");
    for(i = 0; i < n; i++){
        printf("Vetor [%d]: %d\n", i,vet[i]);
    }

    vet = NULL;

    return 0;
}

int *aloca_vetor(int *vet, int n) {
    vet = malloc(n * sizeof(int));
    return vet;
}

void libera_vetor(int *vet) {
    free(vet);
}

void imprime_vetot(int *vet, int n) {

    int i;

    printf("\nVetor:\n\n");
    for (i = 0; i < n; i++) {
        printf("%d ", vet[i]);
    }
}
