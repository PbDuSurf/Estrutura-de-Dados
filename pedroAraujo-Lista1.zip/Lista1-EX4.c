#include <stdio.h>
#include <stdlib.h>
main(){
  
  int i;
  char nome[30];
   
  printf("Digite um nome: ");
   gets(nome);

  for(i=0; i<5; i++){
    
	printf("%i = %s\n", i+1, nome);      
	  
  }
  system("pause");
}

