#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
 
 int x,tam;
 char nome[30];
 
 printf("Digite um nome: ");
 gets(nome);
 tam = strlen(nome);
 
 for (x=1; x <= tam; x++)
 printf("\n%s",nome);
 
 
 printf("\n\n");
 system("pause");
		
return 0;
}
