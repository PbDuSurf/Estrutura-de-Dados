#include <stdio.h>
#include <string.h>

int main(){
	int p = 0;
	int tam = 0;
	int x;
	char nome[30];
	
	printf("\n Digite um nome: ");
	gets(nome);
	
	tam = strlen(nome);
	printf("\n As letras impares sao: ", x);
	
	while(p <= tam - 1){
		printf(" %c ",  nome[p]);
		p += 2;
	}
	printf("\n Nome digitado foi: %s", nome);
	return 0;
}
