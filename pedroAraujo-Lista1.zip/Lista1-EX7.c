
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
 
 int x,tam;
 char nome[30];
 	
 printf("Digite um nome: ");
 gets(nome);
 
 tam = strlen(nome);
 printf("\nEsse nome tem %d\ letras.\n\n",tam);
 
 return 0;
}
