#include <stdio.h>
#include <stdlib.h>
/* Receber um nome e imprimir as 3 primeiras letras do nome */
main(){
  
  int i;
  int tam = 30;   
  char nome[tam]; 

  printf("Digite um nome: ");
  scanf(nome);

  for(i=0; i<=2; i++){
    printf("Letra %d: \%c\n", i+1, nome[i]);
  }

  printf("\n\n");
  system("pause");

}

