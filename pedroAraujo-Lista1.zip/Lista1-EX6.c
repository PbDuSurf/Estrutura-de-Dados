
#include <stdlib.h>
#include <stdio.h>
#include <math.h> 


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
 char nome[30];
 int sexo;
 int idade;
 
 printf("Informe seu nome: ");
 gets(nome);
 
 printf("Informe seu sexo: ");
 scanf("%c",&sexo);
 
 printf("Informe sua idade: ");
 scanf("%d",&idade);
 
 if (sexo == 'f' || sexo == 'F' && idade <18)
 printf("\n%s. Menina.\n\n", nome);
 
 else
 printf("\nMulher.\n\n");
 
 system("PAUSE");
 return 0;
} 

	
	
	
	
	
	
	
	

