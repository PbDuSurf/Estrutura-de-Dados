#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[]){

	char nome[40];
	char endereco[50];
	char telefone[15];
	
	printf("Digite seu nome:\n");
	fgets(nome,40,stdin);
	printf("Digite seu endere�o:\n");
	fgets(endereco,50,stdin);
	printf("Digite seu telefone:\n");
	fgets(telefone,15,stdin);
	
    printf("Nome:%s\nEndereco:%sTelefone:%s",nome,endereco,telefone);

return 0;
}
