#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

    char nome[30];
    int x;
	int t; 
	int ce=0;
    
	printf("\tDigite um Nome : ");
    gets(nome);
    t=strlen(nome);
   
   for (x=1; x <= t-1; x++){
     if (nome[x] == 'e' || nome[x] == 'E')
      ce++;
    }

   printf("\n O nome %s ",(nome));
   printf("tem %d letra E.",ce);
   printf("\n\n");
   system("pause");
return(0);
}
