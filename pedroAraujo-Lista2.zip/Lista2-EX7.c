#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>
#include<string.h>
int main(){
	
float n1=11; 
float n2=13; 
float n3=15; 
float n4=6; 
float n5=7; 
float n6=8; 
float somam; 
float media3;
 
 printf("\n\n A media dos numeros 11, 13 e 15 e = %2.2f\n\n",((n1+n2+n3)) / 3 );
 
 printf("\n\n A media dos numeros 6, 7 e 8 e = %2.2f\n\n",((n4+n5+n6)) / 3 );
 somam = ((n1+n2+n3) /3 ) + ((n4+n5+n6) / 3);
 
 printf("\n\n A soma das duas medias e = %2.2f\n\n",somam );
 media3 = (((n1+n2+n3)/3) + ((n4+n5+n6) /3 )) / 2;
 
 printf("\n\n A media das medias e = %2.2f\n\n",media3);
 printf("\n\n");
 
 return (0);
} 
