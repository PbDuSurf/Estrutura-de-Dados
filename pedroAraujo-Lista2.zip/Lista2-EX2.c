
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <string.h>

int main(){

    char estado[3];

    printf("Informe a sigla de um estado do Brasil: ");
    scanf("%s", estado);

    if(!strcmp(estado,"MG") || !strcmp(estado,"mg"))
    printf("voce e Mineiro\n");

    else if(!strcmp(estado,"RJ") || !strcmp(estado,"rj"))
    printf("voce e Carioca\n");

    else if(!strcmp(estado,"SP") || !strcmp(estado,"sp"))
    printf("voce e Paulista\n");

   else
   printf("Outros estados\n");
   printf("\n");



return 0;

}
