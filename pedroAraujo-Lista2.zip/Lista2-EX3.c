#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	
   char STR1[30],STR2[30];
   
   printf("INFORME UM NOME: ");
   gets(STR1);
   
   printf("\nINFORME UM OUTRO NOME: ");
   gets(STR2);
   
   printf("\nO Tamanho do primeiro nome  e:%d",strlen(STR1));
   
   printf("\nO tamanho do segundo nome:%d",strlen(STR2)); 
   
   printf("\nOs mones digitados foram:%s",strcat(STR1,STR2));

   printf("\n");

   
return(0);
} 

