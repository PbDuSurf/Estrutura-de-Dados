#include <stdio.h>
#include<stdio.h>
#include<stdlib.h>
#include <string.h>

int main(){
	
 char frase[35];
 int x;
 int tam;
 
 printf("\nDigite uma frase: ");
 gets(frase);
 tam=strlen(frase);
 
 while(tam>35){
 	
 printf("\nFrase invalida. Maximo 35 letras.");
 
 printf("\nDigite uma frase novamente: ");
 gets(frase);
 tam=strlen(frase);
 
 }
 printf("\n\n");
 
    for(x = 0; x <= tam; x++)
     
	 printf("\n%c",frase[x]);
     printf("\n\n");
     

 return(0);
} 

