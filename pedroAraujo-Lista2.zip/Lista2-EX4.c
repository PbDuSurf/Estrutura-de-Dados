#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main(){
   
   char nome[30];
   
   printf("\nDigite um nome: ");
   gets(nome);
   
   if(nome[0]=='E'||nome[0]=='e')
   printf("\n%s",nome);
 
   printf("\n\n");

   
return(0);
} 
